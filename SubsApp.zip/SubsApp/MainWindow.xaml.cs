﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SubsApp.Classes;
using SubsApp.Pages;

namespace SubsApp
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            ClassFrame.frmObj = FrmSub;
        }

        private void btnToSubs_Click(object sender, RoutedEventArgs e)
        {
            FrmSub.Navigate(new Pages.PageSubs());
            MainMenu.Visibility = Visibility.Hidden;
            btnToBack.Visibility = Visibility.Visible;
            MainImage.Visibility = Visibility.Hidden;
        }

        private void btnToBack_Click(object sender, RoutedEventArgs e)
        {
            FrmSub.Navigate(null);
            MainMenu.Visibility = Visibility.Visible;
            btnToBack.Visibility = Visibility.Hidden;
            MainImage.Visibility = Visibility.Visible;
        }

        private void btnToSubsInfo_Click(object sender, RoutedEventArgs e)
        {
            FrmSub.Navigate(new Pages.PageSubsInfo());
            MainMenu.Visibility = Visibility.Hidden;
            btnToBack.Visibility = Visibility.Visible;
            MainImage.Visibility = Visibility.Hidden;
        }

        private void btnToOpers_Click(object sender, RoutedEventArgs e)
        {
            FrmSub.Navigate(new Pages.PageOpers());
            MainMenu.Visibility = Visibility.Hidden;
            btnToBack.Visibility = Visibility.Visible;
            MainImage.Visibility = Visibility.Hidden;
        }

        private void btnToServices_Click(object sender, RoutedEventArgs e)
        {
            FrmSub.Navigate(new Pages.PageServices());
            MainMenu.Visibility = Visibility.Hidden;
            btnToBack.Visibility = Visibility.Visible;
            MainImage.Visibility = Visibility.Hidden;
        }

        private void btnToProvisionOfServices_Click(object sender, RoutedEventArgs e)
        {
            FrmSub.Navigate(new Pages.PageProvisionOfServices());
            MainMenu.Visibility = Visibility.Hidden;
            btnToBack.Visibility = Visibility.Visible;
            MainImage.Visibility = Visibility.Hidden;
        }

        private void btnToTypesOfServices_Click(object sender, RoutedEventArgs e)
        {
            FrmSub.Navigate(new Pages.PageTypesOfServices());
            MainMenu.Visibility = Visibility.Hidden;
            btnToBack.Visibility = Visibility.Visible;
            MainImage.Visibility = Visibility.Hidden;
        }
    }
}

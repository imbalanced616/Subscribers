﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SubsApp.Classes;
using Excel = Microsoft.Office.Interop.Excel;

namespace SubsApp.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageProvisionOfServices.xaml
    /// </summary>
    public partial class PageProvisionOfServices : Page
    {
        public PageProvisionOfServices()
        {
            InitializeComponent();
            dtgProvisionsOfServices.ItemsSource = SubscribersEntities.GetContext().ProvisionOfServices.ToList();

            HashSet<string> ts = new HashSet<string>();
            foreach (TypesOfServices type in SubscribersEntities.GetContext().TypesOfServices) ts.Add(type.TypeService);
            List<string> types = ts.ToList();
            for (int i = 0; i < types.Count; i++)
            {
                string type = types[i];
                MenuItem menu = new MenuItem();
                menu.Header = type;
                menu.Click += (s, e) =>
                {
                    dtgProvisionsOfServices.ItemsSource = SubscribersEntities.GetContext().ProvisionOfServices.Where(x => x.Services.TypesOfServices.TypeService == type).ToList();
                };
                this.MenuTypesOfServices.Items.Add(menu);
            }
            this.MenuTypesOfServices.Items.Add(new Separator());
            MenuItem menuSb = new MenuItem();
            menuSb.Header = "Сброс";
            menuSb.Click += new RoutedEventHandler(MenuSortFiltСlear_Click);
            this.MenuTypesOfServices.Items.Add(menuSb);
        }

        private void MenuAdd_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new AddPageProvisionOfServices(null));
        }

        private void MenuEdit_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new AddPageProvisionOfServices((ProvisionOfServices)dtgProvisionsOfServices.SelectedItem));
        }

        private void MenuUpdate_Click(object sender, RoutedEventArgs e)
        {
            dtgProvisionsOfServices.ItemsSource = SubscribersEntities.GetContext().ProvisionOfServices.ToList();
            SearchMargin.Height = new GridLength(9, GridUnitType.Star);
            SearchPanel.Visibility = Visibility.Hidden;
            MenuSearch.Header = "Поиск";
        }

        private void MenuSortASC_Click(object sender, RoutedEventArgs e)
        {
            dtgProvisionsOfServices.ItemsSource = SubscribersEntities.GetContext().ProvisionOfServices.OrderBy(x => x.Subs.FIO).ToList();
        }

        private void MenuSortDESC_Click(object sender, RoutedEventArgs e)
        {
            dtgProvisionsOfServices.ItemsSource = SubscribersEntities.GetContext().ProvisionOfServices.OrderByDescending(x => x.Subs.FIO).ToList();
        }

        private void MenuSortFiltСlear_Click(object sender, RoutedEventArgs e)
        {
            dtgProvisionsOfServices.ItemsSource = SubscribersEntities.GetContext().ProvisionOfServices.ToList();
        }

        private void txbFIO_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (dtgProvisionsOfServices.ItemsSource != null) dtgProvisionsOfServices.ItemsSource = SubscribersEntities.GetContext().ProvisionOfServices.Where(x => x.Subs.FIO.ToLower().Contains(txbFIO.Text.ToLower())).ToList();
            if (txbFIO.Text.Count() == 0) dtgProvisionsOfServices.ItemsSource = SubscribersEntities.GetContext().ProvisionOfServices.ToList();
        }

        private void txbServiceRate_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (dtgProvisionsOfServices.ItemsSource != null) dtgProvisionsOfServices.ItemsSource = SubscribersEntities.GetContext().ProvisionOfServices.Where(predicate: x => x.Services.Rate.ToLower().Contains(txbServiceRate.Text.ToLower())).ToList();
            if (txbServiceRate.Text.Count() == 0) dtgProvisionsOfServices.ItemsSource = SubscribersEntities.GetContext().ProvisionOfServices.ToList();
        }

        private void MenuSearch_Click(object sender, RoutedEventArgs e)
        {
            if (SearchPanel.Visibility == Visibility.Hidden)
            {
                SearchMargin.Height = new GridLength(4.5, GridUnitType.Star);
                SearchPanel.Visibility = Visibility.Visible;
                MenuSearch.Header = "Убрать поиск";
            }
            else
            {
                SearchMargin.Height = new GridLength(9, GridUnitType.Star);
                SearchPanel.Visibility = Visibility.Hidden;
                MenuSearch.Header = "Поиск";
            }
        }

        private void MenuDel_Click(object sender, RoutedEventArgs e)
        {
            var rowsForRemoving = dtgProvisionsOfServices.SelectedItems.Cast<ProvisionOfServices>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {rowsForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    SubscribersEntities.GetContext().ProvisionOfServices.RemoveRange(rowsForRemoving);
                    SubscribersEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    dtgProvisionsOfServices.ItemsSource = SubscribersEntities.GetContext().ProvisionOfServices.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void MenuSaveToExcel_Click(object sender, RoutedEventArgs e)
        {
            Excel.Application excelApp = new Excel.Application();
            Excel.Workbook wb = excelApp.Workbooks.Open($"{Directory.GetCurrentDirectory()}\\Шаблон.xlsx");
            Excel.Worksheet ws = (Excel.Worksheet)wb.Worksheets[1];
            ws.Cells[4, 3] = DateTime.Now.ToString();
            ws.Cells[4, 6] = 5;
            int indexRows = 6;
            ws.Cells[2][2] = "Оказание услуг";
            ws.Cells[1][indexRows] = "№";
            ws.Cells[2][indexRows] = "Абонент";
            ws.Cells[3][indexRows] = "Услуга";
            ws.Cells[4][indexRows] = "Оператор";
            ws.Cells[5][indexRows] = "Тариф";
            var printItems = dtgProvisionsOfServices.Items;
            foreach (ProvisionOfServices item in printItems)
            {
                ws.Cells[1][indexRows + 1] = indexRows - 5;
                ws.Cells[2][indexRows + 1] = item.Subs.FIO;
                ws.Cells[3][indexRows + 1] = item.Services.TypesOfServices.TypeService;
                ws.Cells[4][indexRows + 1] = item.Services.Operators.Operator;
                ws.Cells[5][indexRows + 1] = item.Services.Rate;
                indexRows++;
            }
            ws.Columns.AutoFit();
            ws.Cells[indexRows + 2, 5] = "Подпись";
            ws.Cells[indexRows + 2, 6] = "Рылеев А.Ю.";
            excelApp.Visible = true;
        }
    }
}

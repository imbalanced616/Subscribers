﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SubsApp.Classes;
using Excel = Microsoft.Office.Interop.Excel;

namespace SubsApp.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageTypesOfServices.xaml
    /// </summary>
    public partial class PageTypesOfServices : Page
    {
        public PageTypesOfServices()
        {
            InitializeComponent();
            dtgTypesOfServices.ItemsSource = SubscribersEntities.GetContext().TypesOfServices.ToList();
        }

        private void MenuAdd_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new AddPageTypesOfServices(null));
        }

        private void MenuEdit_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new AddPageTypesOfServices((TypesOfServices)dtgTypesOfServices.SelectedItem));
        }

        private void MenuUpdate_Click(object sender, RoutedEventArgs e)
        {
            dtgTypesOfServices.ItemsSource = SubscribersEntities.GetContext().TypesOfServices.ToList();
            SearchMargin.Height = new GridLength(9, GridUnitType.Star);
            SearchPanel.Visibility = Visibility.Hidden;
            MenuSearch.Header = "Поиск";
        }

        private void MenuSortASC_Click(object sender, RoutedEventArgs e)
        {
            dtgTypesOfServices.ItemsSource = SubscribersEntities.GetContext().TypesOfServices.OrderBy(x => x.TypeService).ToList();
        }

        private void MenuSortDESC_Click(object sender, RoutedEventArgs e)
        {
            dtgTypesOfServices.ItemsSource = SubscribersEntities.GetContext().TypesOfServices.OrderByDescending(x => x.TypeService).ToList();
        }

        private void MenuSortFiltСlear_Click(object sender, RoutedEventArgs e)
        {
            dtgTypesOfServices.ItemsSource = SubscribersEntities.GetContext().TypesOfServices.ToList();
        }

        private void txbType_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (dtgTypesOfServices.ItemsSource != null) dtgTypesOfServices.ItemsSource = SubscribersEntities.GetContext().TypesOfServices.Where(x => x.TypeService.ToLower().Contains(txbType.Text.ToLower())).ToList();
            if (txbType.Text.Count() == 0) dtgTypesOfServices.ItemsSource = SubscribersEntities.GetContext().TypesOfServices.ToList();
        }

        private void MenuSearch_Click(object sender, RoutedEventArgs e)
        {
            if (SearchPanel.Visibility == Visibility.Hidden)
            {
                SearchMargin.Height = new GridLength(4.5, GridUnitType.Star);
                SearchPanel.Visibility = Visibility.Visible;
                MenuSearch.Header = "Убрать поиск";
            }
            else
            {
                SearchMargin.Height = new GridLength(9, GridUnitType.Star);
                SearchPanel.Visibility = Visibility.Hidden;
                MenuSearch.Header = "Поиск";
            }
        }

        private void MenuDelFossil_Click(object sender, RoutedEventArgs e)
        {
            var rowsForRemoving = dtgTypesOfServices.SelectedItems.Cast<TypesOfServices>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {rowsForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    SubscribersEntities.GetContext().TypesOfServices.RemoveRange(rowsForRemoving);
                    SubscribersEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    dtgTypesOfServices.ItemsSource = SubscribersEntities.GetContext().TypesOfServices.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void MenuSaveToExcel_Click(object sender, RoutedEventArgs e)
        {
            Excel.Application excelApp = new Excel.Application();
            Excel.Workbook wb = excelApp.Workbooks.Open($"{Directory.GetCurrentDirectory()}\\Шаблон.xlsx");
            Excel.Worksheet ws = (Excel.Worksheet)wb.Worksheets[1];
            ws.Cells[4, 3] = DateTime.Now.ToString();
            ws.Cells[4, 6] = 6;
            int indexRows = 6;
            ws.Cells[2][2] = "Типы услуг";
            ws.Cells[1][indexRows] = "№";
            ws.Cells[2][indexRows] = "Тип услуги";
            var printItems = dtgTypesOfServices.Items;
            foreach (TypesOfServices item in printItems)
            {
                ws.Cells[1][indexRows + 1] = indexRows - 5;
                ws.Cells[2][indexRows + 1] = item.TypeService;
                indexRows++;
            }
            ws.Columns.AutoFit();
            ws.Cells[indexRows + 2, 5] = "Подпись";
            ws.Cells[indexRows + 2, 6] = "Рылеев А.Ю.";
            excelApp.Visible = true;
        }
    }
}

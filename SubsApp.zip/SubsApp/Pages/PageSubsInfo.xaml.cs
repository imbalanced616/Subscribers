﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SubsApp.Classes;
using Excel = Microsoft.Office.Interop.Excel;

namespace SubsApp.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageSubsInfo.xaml
    /// </summary>
    public partial class PageSubsInfo : Page
    {
        public PageSubsInfo()
        {
            InitializeComponent();
            dtgSubsInfo.ItemsSource = SubscribersEntities.GetContext().Subs.ToList();
        }

        private void MenuAddSubs_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new AddPageSubs(null));
        }

        private void MenuEditSubs_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new AddPageSubs((Subs)dtgSubsInfo.SelectedItem));
        }

        private void MenuUpdateSubs_Click(object sender, RoutedEventArgs e)
        {
            dtgSubsInfo.ItemsSource = SubscribersEntities.GetContext().Subs.ToList();
            SearchMargin.Height = new GridLength(9, GridUnitType.Star);
            SearchPanel.Visibility = Visibility.Hidden;
            MenuSearch.Header = "Поиск";
        }

        private void MenuSortASC_Click(object sender, RoutedEventArgs e)
        {
            dtgSubsInfo.ItemsSource = SubscribersEntities.GetContext().Subs.OrderBy(x => x.FIO).ToList();
        }

        private void MenuSortDESC_Click(object sender, RoutedEventArgs e)
        {
            dtgSubsInfo.ItemsSource = SubscribersEntities.GetContext().Subs.OrderByDescending(x => x.FIO).ToList();
        }

        private void MenuSortFiltСlear_Click(object sender, RoutedEventArgs e)
        {
            dtgSubsInfo.ItemsSource = SubscribersEntities.GetContext().Subs.ToList();
        }

        private void MenuFilter1_Click(object sender, RoutedEventArgs e)
        {
            dtgSubsInfo.ItemsSource = SubscribersEntities.GetContext().Subs.Where(x => x.Balance <= 25000).ToList();
        }

        private void MenuFilter2_Click(object sender, RoutedEventArgs e)
        {
            dtgSubsInfo.ItemsSource = SubscribersEntities.GetContext().Subs.Where(x => x.Balance > 25000 && x.Balance <= 150000).ToList();
        }

        private void MenuFilter3_Click(object sender, RoutedEventArgs e)
        {
            dtgSubsInfo.ItemsSource = SubscribersEntities.GetContext().Subs.Where(x => x.Balance > 150000 && x.Balance <= 500000).ToList();
        }

        private void MenuFilter4_Click(object sender, RoutedEventArgs e)
        {
            dtgSubsInfo.ItemsSource = SubscribersEntities.GetContext().Subs.Where(x => x.Balance > 500000 && x.Balance <= 1000000).ToList();
        }

        private void MenuFilter5_Click(object sender, RoutedEventArgs e)
        {
            dtgSubsInfo.ItemsSource = SubscribersEntities.GetContext().Subs.Where(x => x.Balance > 1000000).ToList();
        }

        private void MenuSearch_Click(object sender, RoutedEventArgs e)
        {
            if (SearchPanel.Visibility == Visibility.Hidden)
            {
                SearchMargin.Height = new GridLength(4.5, GridUnitType.Star);
                SearchPanel.Visibility = Visibility.Visible;
                MenuSearch.Header = "Убрать поиск";
            }
            else
            {
                SearchMargin.Height = new GridLength(9, GridUnitType.Star);
                SearchPanel.Visibility = Visibility.Hidden;
                MenuSearch.Header = "Поиск";
            }
        }

        private void MenuDelSubs_Click(object sender, RoutedEventArgs e)
        {
            var rowsForRemoving = dtgSubsInfo.SelectedItems.Cast<Subs>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {rowsForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    SubscribersEntities.GetContext().Subs.RemoveRange(rowsForRemoving);
                    SubscribersEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    dtgSubsInfo.ItemsSource = SubscribersEntities.GetContext().Subs.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void txbFIO_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (dtgSubsInfo.ItemsSource != null) dtgSubsInfo.ItemsSource = SubscribersEntities.GetContext().Subs.Where(x => x.FIO.ToLower().Contains(txbFIO.Text.ToLower())).ToList();
            if (txbFIO.Text.Count() == 0) dtgSubsInfo.ItemsSource = SubscribersEntities.GetContext().Subs.ToList();
        }

        private void txbCardNumber_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (dtgSubsInfo.ItemsSource != null) dtgSubsInfo.ItemsSource = SubscribersEntities.GetContext().Subs.Where(x => x.CardNumber.ToLower().Contains(txbCardNumber.Text.ToLower())).ToList();
            if (txbCardNumber.Text.Count() == 0) dtgSubsInfo.ItemsSource = SubscribersEntities.GetContext().Subs.ToList();
        }

        private void MenuSaveToExcel_Click(object sender, RoutedEventArgs e)
        {
            Excel.Application excelApp = new Excel.Application();
            Excel.Workbook wb = excelApp.Workbooks.Open($"{Directory.GetCurrentDirectory()}\\Шаблон.xlsx");
            Excel.Worksheet ws = (Excel.Worksheet)wb.Worksheets[1];
            ws.Cells[4, 3] = DateTime.Now.ToString();
            ws.Cells[4, 6] = 2;
            int indexRows = 6;
            ws.Cells[2][2] = "Личные сведения абонентов";
            ws.Cells[1][indexRows] = "№";
            ws.Cells[2][indexRows] = "ФИО";
            ws.Cells[3][indexRows] = "Номер карты";
            ws.Cells[4][indexRows] = "Счёт/баланс (руб.)";
            var printItems = dtgSubsInfo.Items;
            foreach (Subs item in printItems)
            {
                ws.Cells[1][indexRows + 1] = indexRows - 5;
                ws.Cells[2][indexRows + 1] = item.FIO;
                ws.Cells[3][indexRows + 1] = item.CardNumber;
                ws.Cells[4][indexRows + 1] = item.Balance;
                indexRows++;
            }
            ws.Columns.AutoFit();
            ws.Cells[indexRows + 2, 5] = "Подпись";
            ws.Cells[indexRows + 2, 6] = "Рылеев А.Ю.";
            excelApp.Visible = true;
        }
    }
}

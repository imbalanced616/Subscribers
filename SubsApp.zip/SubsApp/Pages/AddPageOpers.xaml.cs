﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SubsApp.Classes;

namespace SubsApp.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddPageOpers.xaml
    /// </summary>
    public partial class AddPageOpers : Page
    {
        private Operators _currentOperators = new Operators();
        public AddPageOpers(Operators selectedOper)
        {
            InitializeComponent();
            if (selectedOper != null)
            {
                _currentOperators = selectedOper;
                txtTitle.Text = "Изменение оператора";
                BtnAdd.Content = "Изменить";
            }
            // Создаём контекст
            DataContext = _currentOperators;
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_currentOperators.Operator)) error.AppendLine("Укажите название оператора");
            if (string.IsNullOrWhiteSpace(_currentOperators.Founder)) error.AppendLine("Укажите основателя");
            if (string.IsNullOrWhiteSpace(_currentOperators.GeneralManager)) error.AppendLine("Укажите ген. директора");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentOperators.YearOfFoundation))) error.AppendLine("Укажите год основания");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentOperators.NumberOfEmployees))) error.AppendLine("Укажите кол-во сотрудников");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentOperators.IDOper == 0)
            {
                SubscribersEntities.GetContext().Operators.Add(_currentOperators);
                try
                {
                    SubscribersEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageSubs());
                    MessageBox.Show("Новый оператор успешно добавлен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    SubscribersEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageOpers());
                    MessageBox.Show("Оператор успешно изменён!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnCance_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageOpers());
        }
    }
}

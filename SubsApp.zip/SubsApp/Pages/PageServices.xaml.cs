﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SubsApp.Classes;
using Excel = Microsoft.Office.Interop.Excel;

namespace SubsApp.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageServices.xaml
    /// </summary>
    public partial class PageServices : Page
    {
        public PageServices()
        {
            InitializeComponent();
            dtgServices.ItemsSource = SubscribersEntities.GetContext().Services.ToList();

            HashSet<string> ts = new HashSet<string>();
            foreach (TypesOfServices type in SubscribersEntities.GetContext().TypesOfServices) ts.Add(type.TypeService);
            List<string> types = ts.ToList();
            for(int i = 0; i < types.Count; i++)
            {
                string type = types[i];
                MenuItem menu = new MenuItem();
                menu.Header = type;
                menu.Click += (s, e) =>
                {
                    dtgServices.ItemsSource = SubscribersEntities.GetContext().Services.Where(x => x.TypesOfServices.TypeService == type).ToList();
                };
                this.MenuTypesOfServices.Items.Add(menu);
            }
            this.MenuTypesOfServices.Items.Add(new Separator());
            MenuItem menuSb = new MenuItem();
            menuSb.Header = "Сброс";
            menuSb.Click += new RoutedEventHandler(MenuSortFiltСlear_Click);
            this.MenuTypesOfServices.Items.Add(menuSb);
        }

        private void MenuAdd_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new AddPageServices(null));
        }

        private void MenuEdit_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new AddPageServices((Services)dtgServices.SelectedItem));
        }

        private void MenuUpdate_Click(object sender, RoutedEventArgs e)
        {
            dtgServices.ItemsSource = SubscribersEntities.GetContext().Services.ToList();
            SearchMargin.Height = new GridLength(9, GridUnitType.Star);
            SearchPanel.Visibility = Visibility.Hidden;
            MenuSearch.Header = "Поиск";
        }

        private void MenuSortASC_Click(object sender, RoutedEventArgs e)
        {
            dtgServices.ItemsSource = SubscribersEntities.GetContext().Services.OrderBy(x => x.PricePerMonth).ToList();
        }

        private void MenuSortDESC_Click(object sender, RoutedEventArgs e)
        {
            dtgServices.ItemsSource = SubscribersEntities.GetContext().Services.OrderByDescending(x => x.PricePerMonth).ToList();
        }

        private void MenuSortFiltСlear_Click(object sender, RoutedEventArgs e)
        {
            dtgServices.ItemsSource = SubscribersEntities.GetContext().Services.ToList();
        }

        private void MenuSearch_Click(object sender, RoutedEventArgs e)
        {
            if (SearchPanel.Visibility == Visibility.Hidden)
            {
                SearchMargin.Height = new GridLength(4.5, GridUnitType.Star);
                SearchPanel.Visibility = Visibility.Visible;
                MenuSearch.Header = "Убрать поиск";
            }
            else
            {
                SearchMargin.Height = new GridLength(9, GridUnitType.Star);
                SearchPanel.Visibility = Visibility.Hidden;
                MenuSearch.Header = "Поиск";
            }
        }

        private void MenuDel_Click(object sender, RoutedEventArgs e)
        {
            var rowsForRemoving = dtgServices.SelectedItems.Cast<Services>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {rowsForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    SubscribersEntities.GetContext().Services.RemoveRange(rowsForRemoving);
                    SubscribersEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    dtgServices.ItemsSource = SubscribersEntities.GetContext().Services.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void txbRate_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (dtgServices.ItemsSource != null) dtgServices.ItemsSource = SubscribersEntities.GetContext().Services.Where(x => x.Rate.ToLower().Contains(txbRate.Text.ToLower())).ToList();
            if (txbRate.Text.Count() == 0) dtgServices.ItemsSource = SubscribersEntities.GetContext().Services.ToList();
        }

        private void txbCharacteristic_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (dtgServices.ItemsSource != null) dtgServices.ItemsSource = SubscribersEntities.GetContext().Services.Where(x => x.Characteristic.ToLower().Contains(txbCharacteristic.Text.ToLower())).ToList();
            if (txbCharacteristic.Text.Count() == 0) dtgServices.ItemsSource = SubscribersEntities.GetContext().Services.ToList();
        }

        private void MenuSaveToExcel_Click(object sender, RoutedEventArgs e)
        {
            Excel.Application excelApp = new Excel.Application();
            Excel.Workbook wb = excelApp.Workbooks.Open($"{Directory.GetCurrentDirectory()}\\Шаблон.xlsx");
            Excel.Worksheet ws = (Excel.Worksheet)wb.Worksheets[1];
            ws.Cells[4, 3] = DateTime.Now.ToString();
            ws.Cells[4, 6] = 4;
            int indexRows = 6;
            ws.Cells[2][2] = "Услуги";
            ws.Cells[1][indexRows] = "№";
            ws.Cells[2][indexRows] = "Оператор";
            ws.Cells[3][indexRows] = "Тариф";
            ws.Cells[4][indexRows] = "Тип услуги";
            ws.Cells[5][indexRows] = "Характеристика";
            ws.Cells[6][indexRows] = "Цена за месяц (руб.)";
            var printItems = dtgServices.Items;
            foreach (Services item in printItems)
            {
                ws.Cells[1][indexRows + 1] = indexRows - 5;
                ws.Cells[2][indexRows + 1] = item.Operators.Operator;
                ws.Cells[3][indexRows + 1] = item.Rate;
                ws.Cells[4][indexRows + 1] = item.TypesOfServices.TypeService;
                ws.Cells[5][indexRows + 1] = item.Characteristic;
                ws.Cells[6][indexRows + 1] = item.PricePerMonth;
                indexRows++;
            }
            ws.Columns.AutoFit();
            ws.Cells[indexRows + 2, 5] = "Подпись";
            ws.Cells[indexRows + 2, 6] = "Рылеев А.Ю.";
            excelApp.Visible = true;
        }
    }
}

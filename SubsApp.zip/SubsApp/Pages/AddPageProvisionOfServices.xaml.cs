﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SubsApp.Classes;

namespace SubsApp.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddPageProvisionOfServices.xaml
    /// </summary>
    public partial class AddPageProvisionOfServices : Page
    {
        private ProvisionOfServices _currentProvisionOfServices = new ProvisionOfServices();
        public AddPageProvisionOfServices(ProvisionOfServices selectedProvisionOfServices)
        {
            InitializeComponent();
            if (selectedProvisionOfServices != null)
            {
                _currentProvisionOfServices = selectedProvisionOfServices;
                txtTitle.Text = "Изменение оказания услуги";
                BtnAdd.Content = "Изменить";
            }
            // Создаём контекст
            DataContext = _currentProvisionOfServices;
            CmbIDSub.ItemsSource = SubscribersEntities.GetContext().Subs.ToList();
            CmbIDSub.SelectedValuePath = "IDSub";
            CmbIDSub.DisplayMemberPath = "FIO";
            CmbIDSer.ItemsSource = SubscribersEntities.GetContext().Services.ToList();
            CmbIDSer.SelectedValuePath = "IDSer";
            CmbIDSer.DisplayMemberPath = "Rate";
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();

            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentProvisionOfServices.IDSub))) error.AppendLine("Укажите абонента");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentProvisionOfServices.IDSer))) error.AppendLine("Укажите услугу (тариф)");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentProvisionOfServices.IDProv == 0)
            {
                SubscribersEntities.GetContext().ProvisionOfServices.Add(_currentProvisionOfServices);
                try
                {
                    SubscribersEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageProvisionOfServices());
                    MessageBox.Show("Новое оказание услуги успешно добавлено!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    SubscribersEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageProvisionOfServices());
                    MessageBox.Show("Оказание услуги успешно изменено!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnCance_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageProvisionOfServices());
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SubsApp.Classes;
using Excel = Microsoft.Office.Interop.Excel;

namespace SubsApp.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageOpers.xaml
    /// </summary>
    public partial class PageOpers : Page
    {
        public PageOpers()
        {
            InitializeComponent();
            dtgOpers.ItemsSource = SubscribersEntities.GetContext().Operators.ToList();
        }

        private void MenuAdd_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new AddPageOpers(null));
        }

        private void MenuEdit_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new AddPageOpers((Operators)dtgOpers.SelectedItem));
        }

        private void MenuUpdate_Click(object sender, RoutedEventArgs e)
        {
            dtgOpers.ItemsSource = SubscribersEntities.GetContext().Operators.ToList();
            SearchMargin.Height = new GridLength(9, GridUnitType.Star);
            SearchPanel.Visibility = Visibility.Hidden;
            MenuSearch.Header = "Поиск";
        }

        private void txbOperator_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (dtgOpers.ItemsSource != null) dtgOpers.ItemsSource = SubscribersEntities.GetContext().Operators.Where(x => x.Operator.ToLower().Contains(txbOperator.Text.ToLower())).ToList();
            if (txbOperator.Text.Count() == 0) dtgOpers.ItemsSource = SubscribersEntities.GetContext().Operators.ToList();
        }

        private void txbGenManager_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (dtgOpers.ItemsSource != null) dtgOpers.ItemsSource = SubscribersEntities.GetContext().Operators.Where(x => x.GeneralManager.ToLower().Contains(txbGenManager.Text.ToLower())).ToList();
            if (txbGenManager.Text.Count() == 0) dtgOpers.ItemsSource = SubscribersEntities.GetContext().Operators.ToList();
        }

        private void MenuSortASC_Click(object sender, RoutedEventArgs e)
        {
            dtgOpers.ItemsSource = SubscribersEntities.GetContext().Operators.OrderBy(x => x.Operator).ToList();
        }

        private void MenuSortDESC_Click(object sender, RoutedEventArgs e)
        {
            dtgOpers.ItemsSource = SubscribersEntities.GetContext().Operators.OrderByDescending(x => x.Operator).ToList();
        }

        private void MenuSortFiltСlear_Click(object sender, RoutedEventArgs e)
        {
            dtgOpers.ItemsSource = SubscribersEntities.GetContext().Operators.ToList();
        }

        private void MenuFilter1_Click(object sender, RoutedEventArgs e)
        {
            dtgOpers.ItemsSource = SubscribersEntities.GetContext().Operators.Where(x => x.NumberOfEmployees <= 10000).ToList();
        }

        private void MenuFilter2_Click(object sender, RoutedEventArgs e)
        {
            dtgOpers.ItemsSource = SubscribersEntities.GetContext().Operators.Where(x => x.NumberOfEmployees > 10000 && x.NumberOfEmployees <= 50000).ToList();
        }

        private void MenuFilter3_Click(object sender, RoutedEventArgs e)
        {
            dtgOpers.ItemsSource = SubscribersEntities.GetContext().Operators.Where(x => x.NumberOfEmployees >= 50000 ).ToList();
        }

        private void MenuSearch_Click(object sender, RoutedEventArgs e)
        {
            if (SearchPanel.Visibility == Visibility.Hidden)
            {
                SearchMargin.Height = new GridLength(4.5, GridUnitType.Star);
                SearchPanel.Visibility = Visibility.Visible;
                MenuSearch.Header = "Убрать поиск";
            }
            else
            {
                SearchMargin.Height = new GridLength(9, GridUnitType.Star);
                SearchPanel.Visibility = Visibility.Hidden;
                MenuSearch.Header = "Поиск";
            }
        }

        private void MenuDel_Click(object sender, RoutedEventArgs e)
        {
            var rowsForRemoving = dtgOpers.SelectedItems.Cast<Operators>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {rowsForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    SubscribersEntities.GetContext().Operators.RemoveRange(rowsForRemoving);
                    SubscribersEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    dtgOpers.ItemsSource = SubscribersEntities.GetContext().Operators.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void MenuSaveToExcel_Click(object sender, RoutedEventArgs e)
        {
            Excel.Application excelApp = new Excel.Application();
            Excel.Workbook wb = excelApp.Workbooks.Open($"{Directory.GetCurrentDirectory()}\\Шаблон.xlsx");
            Excel.Worksheet ws = (Excel.Worksheet)wb.Worksheets[1];
            ws.Cells[4, 3] = DateTime.Now.ToString();
            ws.Cells[4, 6] = 3;
            int indexRows = 6;
            ws.Cells[2][2] = "Операторы";
            ws.Cells[1][indexRows] = "№";
            ws.Cells[2][indexRows] = "Оператор";
            ws.Cells[3][indexRows] = "Основатель";
            ws.Cells[4][indexRows] = "Ген. директор";
            ws.Cells[5][indexRows] = "Год основания";
            ws.Cells[6][indexRows] = "Кол-во сотрудников";
            var printItems = dtgOpers.Items;
            foreach (Operators item in printItems)
            {
                ws.Cells[1][indexRows + 1] = indexRows - 5;
                ws.Cells[2][indexRows + 1] = item.Operator;
                ws.Cells[3][indexRows + 1] = item.Founder;
                ws.Cells[4][indexRows + 1] = item.GeneralManager;
                ws.Cells[5][indexRows + 1] = item.YearOfFoundation;
                ws.Cells[6][indexRows + 1] = item.NumberOfEmployees;
                indexRows++;
            }
            ws.Columns.AutoFit();
            ws.Cells[indexRows + 2, 5] = "Подпись";
            ws.Cells[indexRows + 2, 6] = "Рылеев А.Ю.";
            excelApp.Visible = true;
        }
    }
}

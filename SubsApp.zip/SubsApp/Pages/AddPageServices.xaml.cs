﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SubsApp.Classes;

namespace SubsApp.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddPageServices.xaml
    /// </summary>
    public partial class AddPageServices : Page
    {
        private Services _currentServices = new Services();
        public AddPageServices(Services selectedService)
        {
            InitializeComponent();
            if (selectedService != null)
            {
                _currentServices = selectedService;
                txtTitle.Text = "Изменение услуги";
                BtnAdd.Content = "Изменить";
            }
            // Создаём контекст
            DataContext = _currentServices;
            CmbIDOper.ItemsSource = SubscribersEntities.GetContext().Operators.ToList();
            CmbIDOper.SelectedValuePath = "IDOper";
            CmbIDOper.DisplayMemberPath = "Operator";
            CmbIDTypeS.ItemsSource = SubscribersEntities.GetContext().TypesOfServices.ToList();
            CmbIDTypeS.SelectedValuePath = "IDTypeS";
            CmbIDTypeS.DisplayMemberPath = "TypeService";
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();

            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentServices.IDOper))) error.AppendLine("Укажите оператора");
            if (string.IsNullOrWhiteSpace(_currentServices.Rate)) error.AppendLine("Укажите название трафика");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentServices.IDTypeS))) error.AppendLine("Укажите тип услуги");
            if (string.IsNullOrWhiteSpace(_currentServices.Characteristic)) error.AppendLine("Укажите характеристику");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentServices.PricePerMonth))) error.AppendLine("Укажите цену за месяц (руб.)");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentServices.IDSer == 0)
            {
                SubscribersEntities.GetContext().Services.Add(_currentServices);
                try
                {
                    SubscribersEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageServices());
                    MessageBox.Show("Новая услуга успешно добавлена!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    SubscribersEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageServices());
                    MessageBox.Show("Услуга успешно изменена!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnCance_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageServices());
        }
    }
}

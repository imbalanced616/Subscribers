﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SubsApp.Classes;

namespace SubsApp.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddPageTypesOfServices.xaml
    /// </summary>
    public partial class AddPageTypesOfServices : Page
    {
        private TypesOfServices _currentType = new TypesOfServices();
        public AddPageTypesOfServices(TypesOfServices selectedType)
        {
            InitializeComponent();
            if (selectedType != null)
            {
                _currentType = selectedType;
                txtTitle.Text = "Изменение типа услуги";
                BtnAdd.Content = "Изменить";
            }
            // Создаём контекст
            DataContext = _currentType;
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_currentType.TypeService)) error.AppendLine("Укажите тип услуги");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentType.IDTypeS == 0)
            {
                SubscribersEntities.GetContext().TypesOfServices.Add(_currentType);
                try
                {
                    SubscribersEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageTypesOfServices());
                    MessageBox.Show("Новый тип услуги успешно добавлен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    SubscribersEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageTypesOfServices());
                    MessageBox.Show("Тип услуги успешно изменён!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnCance_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageTypesOfServices());
        }
    }
}

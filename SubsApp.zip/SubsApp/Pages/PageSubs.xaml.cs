﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SubsApp.Classes;
using Excel = Microsoft.Office.Interop.Excel;

namespace SubsApp.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageSubs.xaml
    /// </summary>
    public partial class PageSubs : Page
    {
        public PageSubs()
        {
            InitializeComponent();
            dtgSubs.ItemsSource = SubscribersEntities.GetContext().Subs.ToList();
        }

        private void MenuAddSubs_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new AddPageSubs(null));
        }

        private void MenuEditSubs_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new AddPageSubs((Subs)dtgSubs.SelectedItem));
        }

        private void MenuUpdateSubs_Click(object sender, RoutedEventArgs e)
        {
            dtgSubs.ItemsSource = SubscribersEntities.GetContext().Subs.ToList();
            SearchMargin.Height = new GridLength(9, GridUnitType.Star);
            SearchPanel.Visibility = Visibility.Hidden;
            MenuSearch.Header = "Поиск";
        }

        private void MenuSortASC_Click(object sender, RoutedEventArgs e)
        {
            dtgSubs.ItemsSource = SubscribersEntities.GetContext().Subs.OrderBy(x => x.FIO).ToList();
        }

        private void MenuSortDESC_Click(object sender, RoutedEventArgs e)
        {
            dtgSubs.ItemsSource = SubscribersEntities.GetContext().Subs.OrderByDescending(x => x.FIO).ToList();
        }

        private void MenuSortFiltСlear_Click(object sender, RoutedEventArgs e)
        {
            dtgSubs.ItemsSource = SubscribersEntities.GetContext().Subs.ToList();
        }

        private void MenuSortASC2_Click(object sender, RoutedEventArgs e)
        {
            dtgSubs.ItemsSource = SubscribersEntities.GetContext().Subs.OrderBy(x => x.Adress).ToList();
        }

        private void MenuSortDESC2_Click(object sender, RoutedEventArgs e)
        {
            dtgSubs.ItemsSource = SubscribersEntities.GetContext().Subs.OrderByDescending(x => x.Adress).ToList();
        }

        private void MenuSearch_Click(object sender, RoutedEventArgs e)
        {
            if (SearchPanel.Visibility == Visibility.Hidden)
            {
                SearchMargin.Height = new GridLength(4.5, GridUnitType.Star);
                SearchPanel.Visibility = Visibility.Visible;
                MenuSearch.Header = "Убрать поиск";
            }
            else
            {
                SearchMargin.Height = new GridLength(9, GridUnitType.Star);
                SearchPanel.Visibility = Visibility.Hidden;
                MenuSearch.Header = "Поиск";
            }
        }

        private void MenuDelSubs_Click(object sender, RoutedEventArgs e)
        {
            var rowsForRemoving = dtgSubs.SelectedItems.Cast<Subs>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {rowsForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    SubscribersEntities.GetContext().Subs.RemoveRange(rowsForRemoving);
                    SubscribersEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    dtgSubs.ItemsSource = SubscribersEntities.GetContext().Subs.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void txbFIO_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (dtgSubs.ItemsSource != null) dtgSubs.ItemsSource = SubscribersEntities.GetContext().Subs.Where(x => x.FIO.ToLower().Contains(txbFIO.Text.ToLower())).ToList();
            if (txbFIO.Text.Count() == 0) dtgSubs.ItemsSource = SubscribersEntities.GetContext().Subs.ToList();
        }

        private void txbAdress_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (dtgSubs.ItemsSource != null) dtgSubs.ItemsSource = SubscribersEntities.GetContext().Subs.Where(x => x.Adress.ToLower().Contains(txbAdress.Text.ToLower())).ToList();
            if (txbAdress.Text.Count() == 0) dtgSubs.ItemsSource = SubscribersEntities.GetContext().Subs.ToList();
        }

        private void MenuSaveToExcel_Click(object sender, RoutedEventArgs e)
        {
            Excel.Application excelApp = new Excel.Application();
            Excel.Workbook wb = excelApp.Workbooks.Open($"{Directory.GetCurrentDirectory()}\\Шаблон.xlsx");
            Excel.Worksheet ws = (Excel.Worksheet)wb.Worksheets[1];
            ws.Cells[4, 3] = DateTime.Now.ToString();
            ws.Cells[4, 6] = 1;
            int indexRows = 6;
            ws.Cells[2][2] = "Абоненты";
            ws.Cells[1][indexRows] = "№";
            ws.Cells[2][indexRows] = "ФИО";
            ws.Cells[3][indexRows] = "Адрес";
            ws.Cells[4][indexRows] = "Телефон";
            var printItems = dtgSubs.Items;
            foreach (Subs item in printItems)
            {
                ws.Cells[1][indexRows + 1] = indexRows - 5;
                ws.Cells[2][indexRows + 1] = item.FIO;
                ws.Cells[3][indexRows + 1] = item.Adress;
                ws.Cells[4][indexRows + 1] = item.PhoneNumber;
                indexRows++;
            }
            ws.Columns.AutoFit();
            ws.Cells[indexRows + 2, 5] = "Подпись";
            ws.Cells[indexRows + 2, 6] = "Рылеев А.Ю.";
            excelApp.Visible = true;
        }
    }
}

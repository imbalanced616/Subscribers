﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SubsApp.Classes;

namespace SubsApp.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddPageSubs.xaml
    /// </summary>
    public partial class AddPageSubs : Page
    {
        private Subs _currentSubs = new Subs();
        public AddPageSubs(Subs selectedSub)
        {
            InitializeComponent();
            if (selectedSub != null)
            {
                _currentSubs = selectedSub;
                txtTitle.Text = "Изменение абонента";
                BtnAdd.Content = "Изменить";
            }
            // Создаём контекст
            DataContext = _currentSubs;
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_currentSubs.FIO)) error.AppendLine("Укажите ФИО абонента");
            if (string.IsNullOrWhiteSpace(_currentSubs.Adress)) error.AppendLine("Укажите адрес");
            if (string.IsNullOrWhiteSpace(_currentSubs.PhoneNumber)) error.AppendLine("Укажите телефон");
            if (string.IsNullOrWhiteSpace(_currentSubs.CardNumber)) error.AppendLine("Укажите номер карты");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentSubs.Balance))) error.AppendLine("Укажите счёт/баланс");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentSubs.IDSub == 0)
            {
                SubscribersEntities.GetContext().Subs.Add(_currentSubs);
                try
                {
                    SubscribersEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageSubs());
                    MessageBox.Show("Новый абонент успешно добавлен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    SubscribersEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageSubs());
                    MessageBox.Show("Абонент успешно изменён!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnCance_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageSubs());
        }
    }
}

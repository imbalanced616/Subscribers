﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace SubsApp.Classes
{
    internal class ClassFrame
    {
        public static Frame frmObj; //Объект типа Frame
        //public static void ListWithTypes()
        //{
        //    HashSet<string> tos = new HashSet<string>();
        //    TypesOfServices typesOfServices = SubscribersEntities.GetContext().TypesOfServices.ToList();
        //    SubscribersEntities.GetContext().TypesOfServices.ToList().Count;
        //    for(int i = 0; i < SubscribersEntities.GetContext().TypesOfServices.ToList().Count; i++)
        //    {
        //        tos.Add
        //    }

        //    arrNaklad = new double[dataGridOverHead.Rows.Count - 1];
        //    for (int i = 0; i < SubscribersEntities.GetContext().TypesOfServices.ToList().Count - 1; i++)
        //    {
        //        tos.Add((double)SubscribersEntities.GetContext().TypesOfServices.Rows[i].Cells[3].Value);
        //    }
        //}
    }
}
